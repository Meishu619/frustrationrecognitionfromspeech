import numpy as np
import os
import zytools
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score
from sklearn.metrics import recall_score
from sklearn.preprocessing import StandardScaler

train_x_file_path = '/home/meishu/eihw/data_work/Meishu/frus/mfcc/train/'
validate_x_file_path = '/home/meishu/eihw/data_work/Meishu/frus/mfcc/dev/'
test_x_file_path = '/home/meishu/eihw/data_work/Meishu/frus/mfcc/test/'
longest_len = 999
counter = 0

train_x = []
train_y = []
for filename in os.listdir(train_x_file_path):
    data = zytools.csv_read(train_x_file_path + filename, deli=';', skipc=2, skipr=1)
    data = np.array(data).astype(float)
    data = data.flatten()
    if data.shape[0] < longest_len:
        data = np.pad(data, (0, longest_len - data.shape[0]), 'constant', constant_values=0)
    train_x.append(data)

    label_idx = int(filename[0])
    # label = np.zeros(7)
    # np.put(label, label_idx, 1)
    train_y.append(label_idx)

    counter += 1
    print("-> {}/{}".format(counter, 15477))

train_x = np.array(train_x)
train_y = np.array(train_y)
print("--> Training data finished!")

validate_x = []
validate_y = []
for filename in os.listdir(validate_x_file_path):
    data = zytools.csv_read(validate_x_file_path + filename, deli=';', skipc=2, skipr=1)
    data = np.array(data).astype(float)
    data = data.flatten()
    if data.shape[0] < longest_len:
        data = np.pad(data, (0, longest_len - data.shape[0]), 'constant', constant_values=0)
    validate_x.append(data)

    label_idx = int(filename[0])
    # label = np.zeros(7)
    # np.put(label, label_idx, 1)
    validate_y.append(label_idx)

    counter += 1
    print("-> {}/{}".format(counter, 15477))

validate_x = np.array(validate_x)
validate_y = np.array(validate_y)

print("--> Validation data finished!")

test_x = []
test_y = []
for filename in os.listdir(test_x_file_path):
    data = zytools.feature_read(test_x_file_path + filename, deli=';', skipc=2, skipr=1)
    data = np.array(data).astype(float)
    data = data.flatten()
    if data.shape[0] < longest_len:
        data = np.pad(data, (0, longest_len - data.shape[0]), 'constant', constant_values=0)
    test_x.append(data)

    label_idx = int(filename[0])
    # label = np.zeros(7)
    # np.put(label, label_idx, 1)
    test_y.append(label_idx)

    counter += 1
    print("-> {}/{}".format(counter, 15477))

test_x = np.array(test_x)
test_y = np.array(test_y)

print("--> Test data finished!")

scaler = StandardScaler()
scaler.fit(train_x)
scaler.transform(train_x)
scaler.transform(validate_x)
scaler.transform(test_x)

print("--> Standardisation finished!")

best_acc = 0
best_c = 0

best_uar = 0
best_uar_c = 0

for C in [1]:
    clf = SVC(gamma='auto', C=C, kernel='rbf')
    clf.fit(train_x, train_y)
    pred_y = clf.predict(validate_x)
    acc = accuracy_score(validate_y, pred_y)
    uar = recall_score(validate_y, pred_y, average='macro')
    print("when C value is {}, acc value is {}, uar value is{}".format(C, acc, uar))

    if acc > best_acc:
        best_acc = acc
        best_c = C
    if uar > best_uar:
        best_uar = uar
        best_uar_c = C
print("Highest ACC is: {}".format(best_acc))
print("best c is: {}".format(best_c))

print("Highest UAR is: {}".format(best_uar))
print("best uar_c is: {}".format(best_uar_c))

model = SVC(gamma='auto', C=best_c, kernel='rbf')
model.fit(train_x, train_y)
pre_t = model.predict(test_x)
acc_final = accuracy_score(test_y, pre_t)
uar_final = recall_score(test_y, pre_t, average='macro')
print("With TestSET: when C value is {}, acc_final value is {}, uar_final value is{}".format(C, acc_final, uar_final))

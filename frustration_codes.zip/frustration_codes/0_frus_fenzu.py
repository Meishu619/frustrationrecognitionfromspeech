import pandas as pd
import numpy as np
import os
import shutil
meta_file = "/home/meishu/eihw/data_work/Zijiang/CrazyTrophy/meta.csv"
audio_path = "/home/meishu/eihw/data_work/Zijiang/CrazyTrophy/augmented_audio/"
output_train = "/home/meishu/eihw/data_work/Zijiang/CrazyTrophy/output/train/"
output_dev = "/home/meishu/eihw/data_work/Zijiang/CrazyTrophy/output/dev/"
output_test = "/home/meishu/eihw/data_work/Zijiang/CrazyTrophy/output/test/"

file_list = os.listdir(audio_path)

for item in file_list:
    # print(item)
    mf = pd.read_csv(meta_file)

    s = mf['filename'] == item.split('.')[0]
    # print(mf[s])
    b = mf[s].to_numpy()
    # print(b[0][0])
    # print(b[0][1])
    # print(b[0][2])

    if b[0][0] == 'train':
        print("train")
        print(item)
        print(b[0][2])
        if b[0][2] == "neutral":
            shutil.copy2(audio_path + item, output_train + item.split('.')[0] + '_0' + '.wav')
        else:
            shutil.copy2(audio_path + item, output_train + item.split('.')[0] + '_1' + '.wav')

    elif b[0][0] == 'dev':
        print("dev")
        print(item)
        print(b[0][2])
        if b[0][2] == "neutral":
            shutil.copy2(audio_path + item, output_dev + item.split('.')[0] + '_0' + '.wav')
        else:
            shutil.copy2(audio_path + item, output_dev + item.split('.')[0] + '_1' + '.wav')
    elif b[0][0] == 'test':
        print("test")
        print(item)
        print(b[0][2])
        if b[0][2] == "neutral":
            shutil.copy2(audio_path + item, output_test + item.split('.')[0] + '_0' + '.wav')
        else:
            shutil.copy2(audio_path + item, output_test + item.split('.')[0] + '_1' + '.wav')

    print("processing!!!!!!!!")

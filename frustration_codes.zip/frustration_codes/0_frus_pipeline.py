from __future__ import division
import torch.nn as nn
import os
import numpy as np
import scipy.io.wavfile as wavfile
import scipy.signal as signal
import resnet
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
import torch
import math
import torch.optim as optim
from sklearn.metrics import recall_score
from torch.autograd import Variable
import numpy as np
import os
import pandas as pd
from torch.optim.lr_scheduler import ReduceLROnPlateau as RLROP

# Parameters
N_FFT = 2000
WIN_LENGTH = 2000
HOP_LENGTH = 800
N_OVERLAP = WIN_LENGTH - HOP_LENGTH
N_EPOCHS = 100
NAN_AVOIDER = 1e-06
MAX_LEN = 480258
LABEL_LIST = ['neutral', 'frustration']

group_file = "/home/meishu/eihw/data_work/Zijiang/CrazyTrophy/group.csv"
meta_file = "/home/meishu/eihw/data_work/Zijiang/CrazyTrophy/meta.csv"
# group_file = "/nas/staff/data_work/Zijiang/CrazyTrophy/group.csv"
# meta_file = "/nas/staff/data_work/Zijiang/CrazyTrophy/meta.csv"

class AudioData(Dataset):
    def __init__(self, audio_path, fold, testmode=False):
        def id_to_filelist(id_list):
            all_file_list = os.listdir(audio_path)
            file_list = [audio_path + _ for _ in all_file_list if _.split('_')[0] in id_list]
            return file_list

        super().__init__()
        # Get list of file path
        with open(group_file, 'r') as gf:
            group_data = [_.replace('\n', '') for _ in gf.readlines()]

        group_data = [_.split(',') for _ in group_data]
        train_valid_id = [x for n in group_data[1:] for x in n]
        test_id = [_ for _ in group_data[0]]

        if fold == 0:
            self.path_list = id_to_filelist(test_id)
        elif testmode:
            valid_id = group_data[fold]
            self.path_list = id_to_filelist(valid_id)
        else:
            train_id = list(set(train_valid_id) - set(group_data[fold]))
            self.path_list = id_to_filelist(train_id)

        # Get list of labels
        with open(meta_file, 'r') as mf:
            meta_data = [_.replace('\n', '') for _ in mf.readlines()[1:]]
        self.file_name_list = [_.split(',')[1] + '.wav' for _ in meta_data]
        self.label_list = [_.split(',')[2] for _ in meta_data]

    def __getitem__(self, idx):
        def get_label(f_name):
            file_idx = self.file_name_list.index(f_name)
            label_str = self.label_list[file_idx]
            label_int = LABEL_LIST.index(label_str)
            return label_int

        # Get label
        file_path = self.path_list[idx]
        file_name = file_path.split('/')[-1]
        label = get_label(file_name)

        # Get features
        audio_rate, audio_data = wavfile.read(file_path)
        audio_data = audio_data / (np.amax(np.abs(audio_data)) + NAN_AVOIDER)

        # Pad features to MAX_LEN and convert it to mono
        audio_data = np.pad(audio_data, ((0, MAX_LEN - audio_data.shape[0]), (0, 0)),
                            'constant', constant_values=0)
        audio_data = np.mean(audio_data, axis=1)

        # Normalise features by using energy
        audio_energy = np.sum(audio_data ** 2) / audio_data.shape[0]
        audio_data = audio_data / np.sqrt(audio_energy + NAN_AVOIDER)

        # Get spectrogram
        _, _, spec = signal.spectrogram(audio_data, fs=audio_rate, nfft=N_FFT,
                                        noverlap=N_OVERLAP, nperseg=WIN_LENGTH)
        spec = np.array([np.log(spec + NAN_AVOIDER)])

        return spec, label

    def __len__(self):
        return len(self.path_list)


if __name__ == '__main__':
    data_path = "/home/meishu/eihw/data_work/Zijiang/CrazyTrophy/augmented_audio/"
    # data_path = "/nas/staff/data_work/Zijiang/CrazyTrophy/augmented_audio/"

    audio_dataset = AudioData(data_path, fold=1, testmode=False)
    audio_loader = DataLoader(audio_dataset, batch_size=64, shuffle=True, num_workers=1)

    # counter = 0
    # for batch, (features, labels) in enumerate(audio_loader, 0):
    #     print(features.shape)
    #     counter += labels.shape[0]
    #
    # print('Done!')

    for fold in range(1, 16):
        train_dataset = AudioData(data_path, fold=fold, testmode=False)
        valid_dataset = AudioData(data_path, fold=fold, testmode=True)



EPOCH = 100          # train the training data n times, to save time, we just train 1 epoch
BATCH_SIZE = 16
TIME_STEP = 1001          # rnn time step / image height
INPUT_SIZE = 598      # rnn input size / image width
LR = 0.0001            # learning rate


train_loader = torch.utils.data.DataLoader(train_dataset, batch_size=BATCH_SIZE, shuffle=True)

valid_loader = torch.utils.data.DataLoader(valid_dataset, batch_size=BATCH_SIZE, shuffle=True)

def weight_init(m):
    if isinstance(m, nn.Linear):
        nn.init.xavier_normal_(m.weight)
        nn.init.constant_(m.bias, 0)
    elif isinstance(m, nn.Conv2d):
        nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
    elif isinstance(m, nn.BatchNorm2d):
        nn.init.constant_(m.weight, 1)
        nn.init.constant_(m.bias, 0)


cnn = resnet.resnet18(num_classes=2)

loss_func = nn.CrossEntropyLoss()  # the target label is not one-hotted
optimizer = torch.optim.Adam(cnn.parameters(), lr=LR)  # optimize all parameters


# training and evaluation
for epoch in range(EPOCH):
    # training
    cnn.train()
    for step, (local_batch, local_labels) in enumerate(train_loader):  # gives batch data
        # b_localB = local_batch.view(-1, 1001, 598).float()  # reshape x to (batch, time_step, input_size)
        b_localB = local_batch.float()  # reshape x to (batch, time_step, input_size)
        # print("b_localb type:")
        # print(b_localB.type())
        # b_localB = ((b_localB - mean) / (std + 1e-10)).float().cuda()
        b_localL = local_labels
        # b_localB, b_localL = Variable(b_localB).to(device), Variable(b_localL).to(device)

        # batch y
        output_train = cnn(b_localB)  # rnn output
        loss_train = loss_func(output_train, b_localL)  # cross entropy loss

        print('Training counter: {}'.format(step))

        print('train loss: {}'.format(loss_train))
        optimizer.zero_grad()  # clear gradients for this training step
        loss_train.backward()  # backpropagation, compute gradients
        optimizer.step()  # apply gradients

        with open("./train_loss.log", 'a') as lf:
            lf.write("{},{},{}\n".format(epoch, step, loss_train))
        # if step == 1:
        #    break
    uar_train = recall_score(b_localL.detach().cpu().numpy(), torch.argmax(output_train, dim=1).detach().cpu().numpy(),
                             average='macro')

    # validation
    cnn.eval()

    step = 0
    valid_loss_sum = 0.0
    uar_valid_sum = 0.0
    total = 0
    correct = 0
    min_validation_loss = 5
    label_pred = []
    label_local = []

###########3batchviewsize###########################
    for step, (local_batch, local_labels) in enumerate(valid_loader):  # gives batch data
        # b_localB = local_batch.view(-1, 1001, 598).float() # reshape x to (batch, time_step, input_size)
        b_localB = local_batch.float()
        # b_localB = (b_localB - mean) / (std + 1e-10)
        # #b_localB = torch.DoubleTensor()
        b_localL = local_labels
        # b_localB, b_localL = Variable(b_localB).to(device), Variable(b_localL).to(device)
        output_valid = cnn(b_localB)  # rnn output
        loss_valid = loss_func(output_valid, b_localL)  # cross entropy loss
        valid_loss_sum += loss_valid.item()
        print('validation step: {}'.format(step))
        print('loss: {}'.format(loss_valid))

        correct += (torch.max(output_valid, 1)[1] == b_localL).sum().item()
        total += len(b_localL)
        label_local.append(b_localL.detach().cpu().numpy())
        label_pred.append(torch.argmax(output_valid, dim=1).detach().cpu().numpy())
    if valid_loss_sum / (step + 1) < min_validation_loss:
        min_validation_loss = valid_loss_sum / (step + 1)
        print("save model")
        print('min_validation_loss:{}'.format(min_validation_loss))
        torch.save(cnn, './ best_model.npy')
        with open("./loss_valid.log", 'a') as lf:
            lf.write("{},{},{}\n".format(epoch, step, loss_valid))
    # validation accuracy
    acc_valid = correct / total
    valid_loss = valid_loss_sum / (step + 1)

    label_pred = np.concatenate(label_pred, axis=0)
    label_local = np.concatenate(label_local, axis=0)
    uar_final = recall_score(label_local, label_pred, average='macro')

    #uar_valid_mean = uar_valid_sum / (step + 1)
    print('acc: {}'.format(acc_valid))
    print('uar: {}'.format(uar_final))
    with open("./resuts_acc_uar.log", 'a') as lf:
        lf.write("{},{},{}\n".format(epoch, acc_valid, uar_final))

print("haha")
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.autograd import Variable
from torchvision import datasets, transforms
from torch.utils.data import Dataset
import numpy as np
import os
import pandas as pd
import resnet
import zytools


from sklearn.metrics import recall_score

EPOCH = 100          # train the training data n times, to save time, we just train 1 epoch
BATCH_SIZE = 4
TIME_STEP = 999          # rnn time step / image height
INPUT_SIZE = 38    # rnn input size / image width
LR = 0.0001            # learning rate


# data loader
class Frus(Dataset):
    def __init__(self, file_path, train_test):
        self.file_names = []
        self.labels = []
        self.file_folder = file_path + "/" + train_test + "/"
        for filename in os.listdir(self.file_folder):
            if filename.endswith(".csv"):
                self.file_names.append(filename)
                self.labels.append(filename.split('.')[0].split('_')[3])


    def __getitem__(self, index):
        filename = self.file_names[index]
        data = zytools.feature_read(self.file_folder + filename, deli=';', skipr=1, skipc=3)
        label = int(self.labels[index])
        data = np.array(data)
        if data.shape[0] < 999:
            data = np.pad(data, ((0, 999 - data.shape[0]), (0, 0)), 'constant', constant_values=0)

        return np.array([data]), label

    def __len__(self):
        return len(self.file_names)

g_file_path = '/home/meishu/eihw/data_work/Meishu/frus/mfcc'
# g_file_path = '/nas/staff/data_work/Meishu/frus/mfcc'

train_set = Frus(g_file_path, "train")
train_loader = torch.utils.data.DataLoader(train_set, batch_size=BATCH_SIZE, shuffle=False, num_workers=32)
dev_set = Frus(g_file_path, "dev")
dev_loader = torch.utils.data.DataLoader(dev_set, batch_size=BATCH_SIZE, shuffle=False, num_workers=32)
test_set = Frus(g_file_path, "test")
test_loader = torch.utils.data.DataLoader(test_set, batch_size=BATCH_SIZE, shuffle=False, num_workers=32)

cnn = resnet.wide_resnet50_2()
# cnn = resnet.resnet18(num_classes=2)

loss_func = nn.CrossEntropyLoss()  # the target label is not one-hotted
optimizer = torch.optim.Adam(cnn.parameters(), lr=LR)  # optimize all parameters


# training and evaluation
for epoch in range(EPOCH):
    # training
    cnn.train()
    for step, (local_batch, local_labels) in enumerate(train_loader):  # gives batch data
        # b_localB = local_batch.view(-1, 999, 38).float()  # reshape x to (batch, time_step, input_size)
        b_localB = local_batch.float()  # reshape x to (batch, time_step, input_size)
        # print("b_localb type:")
        # print(b_localB.type())
        # b_localB = ((b_localB - mean) / (std + 1e-10)).float().cuda()
        b_localL = local_labels
        # b_localB, b_localL = Variable(b_localB).to(device), Variable(b_localL).to(device)

        # batch y
        output_train = cnn(b_localB)  # rnn output
        loss_train = loss_func(output_train, b_localL)  # cross entropy loss

        print('Training counter: {}'.format(step))

        print('train loss: {}'.format(loss_train))
        optimizer.zero_grad()  # clear gradients for this training step
        loss_train.backward()  # backpropagation, compute gradients
        optimizer.step()  # apply gradients

        with open("./train_loss_whisper_7.log", 'a') as lf:
            lf.write("{},{},{}\n".format(epoch, step, loss_train))
        # if step == 1:
        #    break
    uar_train = recall_score(b_localL.detach().cpu().numpy(), torch.argmax(output_train, dim=1).detach().cpu().numpy(),
                             average='macro')

    # validation
    cnn.eval()

    step = 0
    valid_loss_sum = 0.0
    uar_valid_sum = 0.0
    total = 0
    correct = 0
    min_validation_loss = 5
    label_pred = []
    label_local = []

    for step, (local_batch, local_labels) in enumerate(dev_loader):  # gives batch data
        # b_localB = local_batch.view(-1, 1001, 598).float() # reshape x to (batch, time_step, input_size)
        b_localB = local_batch.float()
        # b_localB = (b_localB - mean) / (std + 1e-10)
        # #b_localB = torch.DoubleTensor()
        b_localL = local_labels
        # b_localB, b_localL = Variable(b_localB).to(device), Variable(b_localL).to(device)
        output_valid = cnn(b_localB)  # rnn output
        loss_valid = loss_func(output_valid, b_localL)  # cross entropy loss
        valid_loss_sum += loss_valid.item()
        print('validation step: {}'.format(step))
        print('loss: {}'.format(loss_valid))

        correct += (torch.max(output_valid, 1)[1] == b_localL).sum().item()
        total += len(b_localL)
        label_local.append(b_localL.detach().cpu().numpy())
        label_pred.append(torch.argmax(output_valid, dim=1).detach().cpu().numpy())
    if valid_loss_sum / (step + 1) < min_validation_loss:
        min_validation_loss = valid_loss_sum / (step + 1)
        print("save model")
        print('min_validation_loss:{}'.format(min_validation_loss))
        torch.save(cnn, './ best_model.npy')
        with open("./loss_valid.log", 'a') as lf:
            lf.write("{},{},{}\n".format(epoch, step, loss_valid))
    # validation accuracy
    acc_valid = correct / total
    valid_loss = valid_loss_sum / (step + 1)

    label_pred = np.concatenate(label_pred, axis=0)
    label_local = np.concatenate(label_local, axis=0)
    uar_final = recall_score(label_local, label_pred, average='macro')

    # uar_valid_mean = uar_valid_sum / (step + 1)
    print('acc: {}'.format(acc_valid))
    print('uar: {}'.format(uar_final))
    with open("./resuts_acc_uar.log", 'a') as lf:
        lf.write("{},{},{}\n".format(epoch, acc_valid, uar_final))

print("haha")
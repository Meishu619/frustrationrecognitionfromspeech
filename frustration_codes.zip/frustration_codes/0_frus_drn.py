import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.autograd import Variable
from torchvision import datasets, transforms
from torch.utils.data import Dataset
import numpy as np
import os
import pandas as pd
import resnet
import zytools
import scipy.io.wavfile as wavfile
import scipy.signal as signal
import librosa
import torchsummary

from sklearn.metrics import recall_score

EPOCH = 100          # train the training data n times, to save time, we just train 1 epoch
BATCH_SIZE = 4
TIME_STEP = 999          # rnn time step / image height
INPUT_SIZE = 38    # rnn input size / image width
LR = 0.0001            # learning rate


# Parameters
N_FFT = 2000
WIN_LENGTH = 1000
HOP_LENGTH = 800
N_OVERLAP = WIN_LENGTH - HOP_LENGTH
N_EPOCHS = 100
NAN_AVOIDER = 1e-06
MAX_LEN = 480258

# data loader
class Frus(Dataset):
    def __init__(self, file_path, train_test):
        self.file_names = []
        self.labels = []
        self.file_folder = file_path + "/" + train_test + "/"
        for filename in os.listdir(self.file_folder):
            if filename.endswith(".wav"):
                self.file_names.append(filename)
                self.labels.append(filename.split('.')[0].split('_')[3])


    def __getitem__(self, index):
        # filename = self.file_names[index]
        # data = zytools.feature_read(self.file_folder + filename, deli=';', skipr=1, skipc=3)
        label = int(self.labels[index])
        # data = np.array(data)
        # if data.shape[0] < 999:
        #     data = np.pad(data, ((0, 999 - data.shape[0]), (0, 0)), 'constant', constant_values=0)
        #
        # return np.array([data]), label

        filename = self.file_names[index]
        # Get features
        audio_rate, audio_data = wavfile.read(self.file_folder + filename)
        audio_data = audio_data / (np.amax(np.abs(audio_data)) + NAN_AVOIDER)

        # Pad features to MAX_LEN and convert it to mono
        audio_data = np.pad(audio_data, ((0, MAX_LEN - audio_data.shape[0]), (0, 0)),
                            'constant', constant_values=0)
        audio_data = np.mean(audio_data, axis=1)

        # Normalise features by using energy
        audio_energy = np.sum(audio_data ** 2) / audio_data.shape[0]
        audio_data = audio_data / np.sqrt(audio_energy + NAN_AVOIDER)

        # Get spectrogram
        spec = librosa.feature.melspectrogram(audio_data, sr=audio_rate, n_fft=N_FFT,
                                              hop_length=HOP_LENGTH, win_length=WIN_LENGTH)
        spec = np.array([np.log(spec + NAN_AVOIDER)])

        return spec, label

    def __len__(self):
        return len(self.file_names)

g_file_path = '/home/meishu/eihw/data_work/Meishu/frus/output'
# g_file_path = '/nas/staff/data_work/Meishu/frus/output'

train_set = Frus(g_file_path, "train")
train_loader = torch.utils.data.DataLoader(train_set, batch_size=BATCH_SIZE, shuffle=False, num_workers=32)
dev_set = Frus(g_file_path, "dev")
dev_loader = torch.utils.data.DataLoader(dev_set, batch_size=BATCH_SIZE, shuffle=False, num_workers=32)
test_set = Frus(g_file_path, "test")
test_loader = torch.utils.data.DataLoader(test_set, batch_size=BATCH_SIZE, shuffle=False, num_workers=32)

import pdb

import torch.nn as nn
import math
import torch.utils.model_zoo as model_zoo

BatchNorm = nn.BatchNorm2d


# __all__ = ['DRN', 'drn26', 'drn42', 'drn58']


webroot = 'https://tigress-web.princeton.edu/~fy/drn/models/'

model_urls = {
    'resnet50': 'https://download.pytorch.org/models/resnet50-19c8e357.pth',
    'drn-c-26': webroot + 'drn_c_26-ddedf421.pth',
    'drn-c-42': webroot + 'drn_c_42-9d336e8c.pth',
    'drn-c-58': webroot + 'drn_c_58-0a53a92c.pth',
    'drn-d-22': webroot + 'drn_d_22-4bd2f8ea.pth',
    'drn-d-38': webroot + 'drn_d_38-eebb45f0.pth',
    'drn-d-54': webroot + 'drn_d_54-0e0534ff.pth',
    'drn-d-105': webroot + 'drn_d_105-12b40979.pth'
}


def conv3x3(in_planes, out_planes, stride=1, padding=1, dilation=1):
    return nn.Conv2d(in_planes, out_planes, kernel_size=3, stride=stride,
                     padding=padding, bias=False, dilation=dilation)


class BasicBlock(nn.Module):
    expansion = 1

    def __init__(self, inplanes, planes, stride=1, downsample=None,
                 dilation=(1, 1), residual=True):
        super(BasicBlock, self).__init__()
        self.conv1 = conv3x3(inplanes, planes, stride,
                             padding=dilation[0], dilation=dilation[0])
        self.bn1 = BatchNorm(planes)
        self.relu = nn.ReLU(inplace=True)
        self.conv2 = conv3x3(planes, planes,
                             padding=dilation[1], dilation=dilation[1])
        self.bn2 = BatchNorm(planes)
        self.downsample = downsample
        self.stride = stride
        self.residual = residual

    def forward(self, x):
        residual = x

        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)

        out = self.conv2(out)
        out = self.bn2(out)

        if self.downsample is not None:
            residual = self.downsample(x)
        if self.residual:
            out += residual
        out = self.relu(out)

        return out


class Bottleneck(nn.Module):
    expansion = 4

    def __init__(self, inplanes, planes, stride=1, downsample=None,
                 dilation=(1, 1), residual=True):
        super(Bottleneck, self).__init__()
        self.conv1 = nn.Conv2d(inplanes, planes, kernel_size=1, bias=False)
        self.bn1 = BatchNorm(planes)
        self.conv2 = nn.Conv2d(planes, planes, kernel_size=3, stride=stride,
                               padding=dilation[1], bias=False,
                               dilation=dilation[1])
        self.bn2 = BatchNorm(planes)
        self.conv3 = nn.Conv2d(planes, planes * 4, kernel_size=1, bias=False)
        self.bn3 = BatchNorm(planes * 4)
        self.relu = nn.ReLU(inplace=True)
        self.downsample = downsample
        self.stride = stride

    def forward(self, x):
        residual = x

        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)

        out = self.conv2(out)
        out = self.bn2(out)
        out = self.relu(out)

        out = self.conv3(out)
        out = self.bn3(out)

        if self.downsample is not None:
            residual = self.downsample(x)

        out += residual
        out = self.relu(out)

        return out


class DRN(nn.Module):

    def __init__(self, block, layers, num_classes=2,
                 channels=(16, 32, 64, 128, 256, 512, 512, 512),
                 out_map=False, out_middle=False, pool_size=28, arch='D'):
        super(DRN, self).__init__()
        self.inplanes = channels[0]
        self.out_map = out_map
        self.out_dim = channels[-1]
        self.out_middle = out_middle
        self.arch = arch

        if arch == 'C':
            self.conv1 = nn.Conv2d(1, channels[0], kernel_size=7, stride=1,
                                   padding=3, bias=False)
            self.bn1 = BatchNorm(channels[0])
            self.relu = nn.ReLU(inplace=True)

            self.layer1 = self._make_layer(
                BasicBlock, channels[0], layers[0], stride=1)
            self.layer2 = self._make_layer(
                BasicBlock, channels[1], layers[1], stride=2)
        elif arch == 'D':
            self.layer0 = nn.Sequential(
                nn.Conv2d(1, channels[0], kernel_size=7, stride=1, padding=3,
                          bias=False),
                BatchNorm(channels[0]),
                nn.ReLU(inplace=True)
            )

            self.layer1 = self._make_conv_layers(
                channels[0], layers[0], stride=1)
            self.layer2 = self._make_conv_layers(
                channels[1], layers[1], stride=2)

        self.layer3 = self._make_layer(block, channels[2], layers[2], stride=2)
        self.layer4 = self._make_layer(block, channels[3], layers[3], stride=2)
        self.layer5 = self._make_layer(block, channels[4], layers[4],
                                       dilation=2, new_level=False)
        self.layer6 = None if layers[5] == 0 else \
            self._make_layer(block, channels[5], layers[5], dilation=4,
                             new_level=False)

        if arch == 'C':
            self.layer7 = None if layers[6] == 0 else \
                self._make_layer(BasicBlock, channels[6], layers[6], dilation=2,
                                 new_level=False, residual=False)
            self.layer8 = None if layers[7] == 0 else \
                self._make_layer(BasicBlock, channels[7], layers[7], dilation=1,
                                 new_level=False, residual=False)
        elif arch == 'D':
            self.layer7 = None if layers[6] == 0 else \
                self._make_conv_layers(channels[6], layers[6], dilation=2)
            self.layer8 = None if layers[7] == 0 else \
                self._make_conv_layers(channels[7], layers[7], dilation=1)

        if num_classes > 0:
            self.avgpool = nn.AvgPool2d(pool_size)
            self.fc = nn.Conv2d(self.out_dim, num_classes, kernel_size=1,
                                stride=1, padding=0, bias=True)
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                n = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
                m.weight.data.normal_(0, math.sqrt(2. / n))
            elif isinstance(m, BatchNorm):
                m.weight.data.fill_(1)
                m.bias.data.zero_()

    def _make_layer(self, block, planes, blocks, stride=1, dilation=1,
                    new_level=True, residual=True):
        assert dilation == 1 or dilation % 2 == 0
        downsample = None
        if stride != 1 or self.inplanes != planes * block.expansion:
            downsample = nn.Sequential(
                nn.Conv2d(self.inplanes, planes * block.expansion,
                          kernel_size=1, stride=stride, bias=False),
                BatchNorm(planes * block.expansion),
            )

        layers = list()
        layers.append(block(
            self.inplanes, planes, stride, downsample,
            dilation=(1, 1) if dilation == 1 else (
                dilation // 2 if new_level else dilation, dilation),
            residual=residual))
        self.inplanes = planes * block.expansion
        for i in range(1, blocks):
            layers.append(block(self.inplanes, planes, residual=residual,
                                dilation=(dilation, dilation)))

        return nn.Sequential(*layers)

    def _make_conv_layers(self, channels, convs, stride=1, dilation=1):
        modules = []
        for i in range(convs):
            modules.extend([
                nn.Conv2d(self.inplanes, channels, kernel_size=3,
                          stride=stride if i == 0 else 1,
                          padding=dilation, bias=False, dilation=dilation),
                BatchNorm(channels),
                nn.ReLU(inplace=True)])
            self.inplanes = channels
        return nn.Sequential(*modules)

    def forward(self, x):
        y = list()

        if self.arch == 'C':
            x = self.conv1(x)
            x = self.bn1(x)
            x = self.relu(x)
        elif self.arch == 'D':
            x = self.layer0(x)

        x = self.layer1(x)
        y.append(x)
        x = self.layer2(x)
        y.append(x)

        x = self.layer3(x)
        y.append(x)

        x = self.layer4(x)
        y.append(x)

        x = self.layer5(x)
        y.append(x)

        if self.layer6 is not None:
            x = self.layer6(x)
            y.append(x)

        if self.layer7 is not None:
            x = self.layer7(x)
            y.append(x)

        if self.layer8 is not None:
            x = self.layer8(x)
            y.append(x)

        if self.out_map:
            x = self.fc(x)
        else:
            x = self.avgpool(x)
            x = self.fc(x)
            x = x.view(x.size(0), -1)

        if self.out_middle:
            return x, y
        else:
            return x


class DRN_A(nn.Module):

    def __init__(self, block, layers, num_classes=2):
        self.inplanes = 64
        super(DRN_A, self).__init__()
        self.out_dim = 512 * block.expansion
        self.conv1 = nn.Conv2d(1, 64, kernel_size=7, stride=2, padding=3,
                               bias=False)
        self.bn1 = nn.BatchNorm2d(64)
        self.relu = nn.ReLU(inplace=True)
        self.maxpool = nn.MaxPool2d(kernel_size=3, stride=2, padding=1)
        self.layer1 = self._make_layer(block, 64, layers[0])
        self.layer2 = self._make_layer(block, 128, layers[1], stride=2)
        self.layer3 = self._make_layer(block, 256, layers[2], stride=1,
                                       dilation=2)
        self.layer4 = self._make_layer(block, 512, layers[3], stride=1,
                                       dilation=4)
        self.avgpool = nn.AdaptiveAvgPool(28, stride=1)
        self.fc = nn.Linear(512 * block.expansion, num_classes)

        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                n = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
                m.weight.data.normal_(0, math.sqrt(2. / n))
            elif isinstance(m, BatchNorm):
                m.weight.data.fill_(1)
                m.bias.data.zero_()

        # for m in self.modules():
        #     if isinstance(m, nn.Conv2d):
        #         nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
        #     elif isinstance(m, nn.BatchNorm2d):
        #         nn.init.constant_(m.weight, 1)
        #         nn.init.constant_(m.bias, 0)

    def _make_layer(self, block, planes, blocks, stride=1, dilation=1):
        downsample = None
        if stride != 1 or self.inplanes != planes * block.expansion:
            downsample = nn.Sequential(
                nn.Conv2d(self.inplanes, planes * block.expansion,
                          kernel_size=1, stride=stride, bias=False),
                nn.BatchNorm2d(planes * block.expansion),
            )

        layers = []
        layers.append(block(self.inplanes, planes, stride, downsample))
        self.inplanes = planes * block.expansion
        for i in range(1, blocks):
            layers.append(block(self.inplanes, planes,
                                dilation=(dilation, dilation)))

        return nn.Sequential(*layers)

    def forward(self, x):
        x = self.conv1(x)
        x = self.bn1(x)
        x = self.relu(x)
        x = self.maxpool(x)

        x = self.layer1(x)
        x = self.layer2(x)
        x = self.layer3(x)
        x = self.layer4(x)

        x = self.avgpool(x)
        x = x.view(x.size(0), -1)
        x = self.fc(x)

        return x


def drn_a_50(pretrained=False, **kwargs):
    model = DRN_A(Bottleneck, [3, 4, 6, 3], **kwargs)
    if pretrained:
        model.load_state_dict(model_zoo.load_url(model_urls['resnet50']))
    return model


def drn_c_26(pretrained=False, **kwargs):
    model = DRN(BasicBlock, [1, 1, 2, 2, 2, 2, 1, 1], arch='C', **kwargs)
    if pretrained:
        model.load_state_dict(model_zoo.load_url(model_urls['drn-c-26']))
    return model


def drn_c_42(pretrained=False, **kwargs):
    model = DRN(BasicBlock, [1, 1, 3, 4, 6, 3, 1, 1], arch='C', **kwargs)
    if pretrained:
        model.load_state_dict(model_zoo.load_url(model_urls['drn-c-42']))
    return model


def drn_c_58(pretrained=False, **kwargs):
    model = DRN(Bottleneck, [1, 1, 3, 4, 6, 3, 1, 1], arch='C', **kwargs)
    if pretrained:
        model.load_state_dict(model_zoo.load_url(model_urls['drn-c-58']))
    return model


def drn_d_22(pretrained=False, **kwargs):
    model = DRN(BasicBlock, [1, 1, 2, 2, 2, 2, 1, 1], arch='D', **kwargs)
    if pretrained:
        model.load_state_dict(model_zoo.load_url(model_urls['drn-d-22']))
    return model


def drn_d_24(pretrained=False, **kwargs):
    model = DRN(BasicBlock, [1, 1, 2, 2, 2, 2, 2, 2], arch='D', **kwargs)
    if pretrained:
        model.load_state_dict(model_zoo.load_url(model_urls['drn-d-24']))
    return model


def drn_d_38(pretrained=False, **kwargs):
    model = DRN(BasicBlock, [1, 1, 3, 4, 6, 3, 1, 1], arch='D', **kwargs)
    if pretrained:
        model.load_state_dict(model_zoo.load_url(model_urls['drn-d-38']))
    return model


def drn_d_40(pretrained=False, **kwargs):
    model = DRN(BasicBlock, [1, 1, 3, 4, 6, 3, 2, 2], arch='D', **kwargs)
    if pretrained:
        model.load_state_dict(model_zoo.load_url(model_urls['drn-d-40']))
    return model


def drn_d_54(pretrained=False, **kwargs):
    model = DRN(Bottleneck, [1, 1, 3, 4, 6, 3, 1, 1], arch='D', **kwargs)
    if pretrained:
        model.load_state_dict(model_zoo.load_url(model_urls['drn-d-54']))
    return model


def drn_d_56(pretrained=False, **kwargs):
    model = DRN(Bottleneck, [1, 1, 3, 4, 6, 3, 2, 2], arch='D', **kwargs)
    if pretrained:
        model.load_state_dict(model_zoo.load_url(model_urls['drn-d-56']))
    return model


def drn_d_105(pretrained=False, **kwargs):
    model = DRN(Bottleneck, [1, 1, 3, 4, 23, 3, 1, 1], arch='D', **kwargs)
    if pretrained:
        model.load_state_dict(model_zoo.load_url(model_urls['drn-d-105']))
    return model


def drn_d_107(pretrained=False, **kwargs):
    model = DRN(Bottleneck, [1, 1, 3, 4, 23, 3, 2, 2], arch='D', **kwargs)
    if pretrained:
        model.load_state_dict(model_zoo.load_url(model_urls['drn-d-107']))
    return model

cnn = drn_d_56()
# torchsummary.summary(cnn, (1, 128, 601))

loss_func = nn.CrossEntropyLoss()  # the target label is not one-hotted
optimizer = torch.optim.Adam(cnn.parameters(), lr=LR)  # optimize all parameters



for epoch in range(EPOCH):
    # training
    cnn.train()
    for step, (local_batch, local_labels) in enumerate(train_loader):  # gives batch data
        # b_localB = local_batch.view(-1, 999, 38).float()  # reshape x to (batch, time_step, input_size)
        b_localB = local_batch.float()  # reshape x to (batch, time_step, input_size)
        # print("b_localb type:")
        # print(b_localB.type())
        # b_localB = ((b_localB - mean) / (std + 1e-10)).float().cuda()
        b_localL = local_labels
        # b_localB, b_localL = Variable(b_localB).to(device), Variable(b_localL).to(device)

        # batch y
        output_train = cnn(b_localB)  # rnn output
        loss_train = loss_func(output_train, b_localL)  # cross entropy loss

        print('Training counter: {}'.format(step))

        print('train loss: {}'.format(loss_train))
        optimizer.zero_grad()  # clear gradients for this training step
        loss_train.backward()  # backpropagation, compute gradients
        optimizer.step()  # apply gradients

        with open("/home/meishu/eihw/data_work/Meishu/frus/melspec_result/resnet_drn/train_loss_whisper_7.log", 'a') as lf:
            lf.write("{},{},{}\n".format(epoch, step, loss_train))
        # if step == 1:
        #    break
    uar_train = recall_score(b_localL.detach().cpu().numpy(), torch.argmax(output_train, dim=1).detach().cpu().numpy(),
                             average='macro')

    # validation
    cnn.eval()

    step = 0
    valid_loss_sum = 0.0
    uar_valid_sum = 0.0
    total = 0
    correct = 0
    min_validation_loss = 5
    label_pred = []
    label_local = []

    for step, (local_batch, local_labels) in enumerate(dev_loader):  # gives batch data
        # b_localB = local_batch.view(-1, 1001, 598).float() # reshape x to (batch, time_step, input_size)
        b_localB = local_batch.float()
        # b_localB = (b_localB - mean) / (std + 1e-10)
        # #b_localB = torch.DoubleTensor()
        b_localL = local_labels
        # b_localB, b_localL = Variable(b_localB).to(device), Variable(b_localL).to(device)
        output_valid = cnn(b_localB)  # rnn output
        loss_valid = loss_func(output_valid, b_localL)  # cross entropy loss
        valid_loss_sum += loss_valid.item()
        print('validation step: {}'.format(step))
        print('loss: {}'.format(loss_valid))

        correct += (torch.max(output_valid, 1)[1] == b_localL).sum().item()
        total += len(b_localL)
        label_local.append(b_localL.detach().cpu().numpy())
        label_pred.append(torch.argmax(output_valid, dim=1).detach().cpu().numpy())
    if valid_loss_sum / (step + 1) < min_validation_loss:
        min_validation_loss = valid_loss_sum / (step + 1)
        print("save model")
        print('min_validation_loss:{}'.format(min_validation_loss))
        torch.save(cnn, '/home/meishu/eihw/data_work/Meishu/frus/melspec_result/resnet_drn/best_model.npy')
        with open("/home/meishu/eihw/data_work/Meishu/frus/melspec_result/resnet_drn/loss_valid.log", 'a') as lf:
            lf.write("{},{},{}\n".format(epoch, step, loss_valid))
    # validation accuracy
    acc_valid = correct / total
    valid_loss = valid_loss_sum / (step + 1)

    label_pred = np.concatenate(label_pred, axis=0)
    label_local = np.concatenate(label_local, axis=0)
    uar_final = recall_score(label_local, label_pred, average='macro')

    # uar_valid_mean = uar_valid_sum / (step + 1)
    print('acc: {}'.format(acc_valid))
    print('uar: {}'.format(uar_final))
    with open("/home/meishu/eihw/data_work/Meishu/frus/melspec_result/resnet_drn/resuts_acc_uar.log", 'a') as lf:
        lf.write("{},{},{}\n".format(epoch, acc_valid, uar_final))

print("haha")

